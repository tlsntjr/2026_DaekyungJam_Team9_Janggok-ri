using UnityEngine;
using UnityEngine.Rendering.Universal;

public class PhaseVisionModifier : MonoBehaviour, IThreatBehavior
{
    [Header("�þ� ���� ���")]
    [SerializeField] private Light2D playerFlashlight; // �÷��̾��� ������ 

    [Header("�þ� ����")]
    [SerializeField] private float visionMultiplier = 0.7f; // 30% ����

    private float originalOuterAngle;
    private float originalOuterRadius;
    public bool IsNeutralized { get; private set; }

    public void Activate()
    {
        IsNeutralized = false;
        if (playerFlashlight != null)
        {
            originalOuterAngle = playerFlashlight.pointLightOuterAngle;
            originalOuterRadius = playerFlashlight.pointLightOuterRadius;

            // �þ� 30% ���� ����
            playerFlashlight.pointLightOuterAngle *= visionMultiplier;
            playerFlashlight.pointLightOuterRadius *= visionMultiplier;
            Debug.Log("<color=cyan>[PhaseVisionModifier]</color> �þ� 30% ����!");
        }
    }

    public void Neutralize()
    {
        if (IsNeutralized) return;
        if (playerFlashlight != null)
        {
            // �þ� ����
            playerFlashlight.pointLightOuterAngle = originalOuterAngle;
            playerFlashlight.pointLightOuterRadius = originalOuterRadius;
        }
        IsNeutralized = true;
    }

    public void Tick() { }
    public void SetProgress(float t) { }
}