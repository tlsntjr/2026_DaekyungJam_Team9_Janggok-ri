using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovement : MonoBehaviour
{
	[Header("�⺻ �÷��̾� ����")]
	[SerializeField] private float moveSpeed							= 5f;
	[SerializeField] private float contaminationSpeedMultiplier	= 0.7f; // ������ ����

	private Rigidbody2D rb;
	private Vector2 input;
	private float speedMultiplier = 1f;

    private void Awake()
	{
		rb = GetComponent<Rigidbody2D>();
	}
	private void OnEnable()	=> EventBus.OnContaminationStageChanged		+= HandleStage;
    private void OnDisable()	=> EventBus.OnContaminationStageChanged		-= HandleStage;
    /// <summary>
    /// ������ �ܰ� ��ȭ��
    /// </summary>
    /// <param name="stage">���� ������ �ܰ�</param>
    private void HandleStage(int stage) => speedMultiplier = stage >= 3 ? contaminationSpeedMultiplier : 1f;

    private void Update()
	{
		input.x = Input.GetAxisRaw("Horizontal");
		input.y = Input.GetAxisRaw("Vertical"); 
		input = input.normalized;                 
	}

    private void FixedUpdate()
	{
		rb.MovePosition(rb.position + input * moveSpeed * Time.fixedDeltaTime);
	}
}
