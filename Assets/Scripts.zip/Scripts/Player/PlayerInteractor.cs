using UnityEngine;

public class PlayerInteractor : MonoBehaviour
{
	[Header("��ȣ�ۿ� ���� �� ����")]
	[SerializeField] private float interactRadius		= 1.2f;
	[SerializeField] private KeyCode interactKey		= KeyCode.E;
	[SerializeField] private LayerMask interactableMask;

	public string CurrentPrompt						{ get; private set; }
	public Transform CurrentTargetTransform		{ get; private set; }

	private IInteractable current;

	private void Update()
	{
		current						= FindNearest(out Transform targetTransform);
		CurrentPrompt				= current?.Prompt;
		CurrentTargetTransform	= targetTransform;

		if (current != null && Input.GetKeyDown(interactKey))
			current.Interact();
	}

	/// <summary>
	/// ��ó ��ȣ�ۿ� ������ ������Ʈ Ž��
	/// ���� ����� �ͺ���
	/// </summary>
	/// <returns></returns>
	private IInteractable FindNearest(out Transform targetTransform)
	{
		var hits							= Physics2D.OverlapCircleAll(transform.position, interactRadius, interactableMask);
		IInteractable best				= null;
		Transform bestTransform	= null;
		float bestDist					= float.MaxValue;

		foreach (var hit in hits)
		{
			var interactable = hit.GetComponent<IInteractable>();
			if (interactable == null) continue;

			float d = Vector2.Distance(transform.position, hit.transform.position);
			if (d < bestDist) { bestDist = d; best = interactable; bestTransform = hit.transform; }
		}

		targetTransform = bestTransform;
		return best;
	}
}