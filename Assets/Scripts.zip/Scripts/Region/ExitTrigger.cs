using UnityEngine;

/// <summary>
/// �� Ż�� �ⱸ�� ���� ��
/// </summary>
public class ExitTrigger : MonoBehaviour
{
    [SerializeField] HauntController haunt;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        Debug.Log("[Test] Exit Activated!");
        haunt.CompleteHaunt();
    }
}