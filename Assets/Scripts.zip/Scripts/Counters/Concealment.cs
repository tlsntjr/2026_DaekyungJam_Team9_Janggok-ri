using UnityEngine;

/// <summary>
/// ���Ͱ� �ð� �� û������ ���� ���ϴ� ���� Ŭ����
/// </summary>
public class Concealment : MonoBehaviour
{
    static int insideCount;
    public static bool IsPlayerConcealed => insideCount > 0;

    public bool PlayerInside { get; private set; }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        PlayerInside = true;
        insideCount++;
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        PlayerInside = false;
        insideCount--;
    }
}