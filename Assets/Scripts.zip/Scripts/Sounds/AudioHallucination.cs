using FMODUnity;
using UnityEngine;
using System.Collections;

public class AudioHallucination : MonoBehaviour
{
	[Header("FMOD Sounds")]
	[SerializeField] private EventReference[] hallucinationSfx;

	[Header("�÷��̾� ����")]
	[SerializeField] private Transform player;
	[SerializeField] private float minInterval		= 8f;
	[SerializeField] private float maxInterval		= 25f;
	[SerializeField] private float randomRadius	= 3f; 
	[SerializeField] private int minStage			= 2;

	private Coroutine loopCoroutine;

	private void OnEnable() => EventBus.OnContaminationStageChanged += HandleStageChanged;
	private void OnDisable()
	{
		EventBus.OnContaminationStageChanged -= HandleStageChanged;
		if (loopCoroutine != null) StopCoroutine(loopCoroutine);
	}

	/// <summary>
	/// �������� ��ȭ��, 2�ܰ� �̻���� ȯû
	/// </summary>
	/// <param name="stage"></param>
	private void HandleStageChanged(int stage)
	{
		if (stage >= minStage && loopCoroutine == null)
			loopCoroutine = StartCoroutine(HallucinationLoop());
		else if (stage < minStage && loopCoroutine != null)
		{
			StopCoroutine(loopCoroutine);
			loopCoroutine = null;
		}
	}

	/// <summary>
	/// ȯû ����, 2�ܰ� �̻���� ��� �ݺ�
	/// </summary>
	/// <returns></returns>
	private IEnumerator HallucinationLoop()
	{
		while (true)
		{
			yield return new WaitForSeconds(Random.Range(minInterval, maxInterval));
			if (hallucinationSfx.Length == 0) continue;

			var sfx			= hallucinationSfx[Random.Range(0, hallucinationSfx.Length)];
			Vector3 pos		= player.position + (Vector3)(Random.insideUnitCircle * randomRadius);

			SoundManager.Instance.PlayOneShot(sfx, pos);
		}
	}
}