using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneFlow : MonoBehaviour
{
	public static SceneFlow Instance { get; private set; }

	[Header("UI - Screen for Fade In/Out")]
	[SerializeField] private CanvasGroup fadeOverlay;

	[Header("Fade Duration")]
	[SerializeField] private float fadeDuration = 0.8f;

	private void Awake()
	{
		if (Instance != null)   { Destroy(gameObject); return; }
		Instance = this;
		DontDestroyOnLoad(gameObject);
	}

	/// <summary>
	/// Scene �ε�
	/// </summary>
	/// <param name="sceneName">�� �̸�</param>
	public void LoadScene(string sceneName)			=> SceneManager.LoadScene(sceneName);
	/// <summary>
	/// Scene �ε�, �ε� ���� Fade ȣ��
	/// </summary>
	/// <param name="sceneName">�� �̸�</param>
	public void FadeAndLoad(string sceneName)		=> StartCoroutine(FadeRoutine(sceneName));

    private IEnumerator FadeRoutine(string sceneName)
	{
		yield return Fade(0f, 1f);
		SceneManager.LoadScene(sceneName);
		yield return Fade(1f, 0f);
	}

    private IEnumerator Fade(float from, float to)
	{
		float t = 0f;
		while (t < fadeDuration)
		{
			t += Time.unscaledDeltaTime;	// �Ͻ����� �߿��� ���̵� ��/�ƿ� ���� �ǵ��� unscaled ���
			fadeOverlay.alpha = Mathf.Lerp(from, to, t / fadeDuration);
			yield return null;
		}
		fadeOverlay.alpha = to;
	}
}