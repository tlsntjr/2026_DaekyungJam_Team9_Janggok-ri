using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class IngameHUD : MonoBehaviour
{
	[Header("���� ������")]
	[SerializeField] private Image contaminationFill;

	[Header("��ȣ�ۿ� ������Ʈ")]
	[SerializeField] private GameObject promptPanel;
	[SerializeField] private TMP_Text promptText;
	[SerializeField] private PlayerInteractor interactor;

	private void OnEnable()		=> EventBus.OnContaminationChanged		+= HandleContaminationChanged;
	private void OnDisable()		=> EventBus.OnContaminationChanged		-= HandleContaminationChanged;

	private void HandleContaminationChanged(float value)
	{
		contaminationFill.fillAmount = value;
	}

	private void Update()
	{
		string prompt = interactor.CurrentPrompt;
		promptPanel.SetActive(!string.IsNullOrEmpty(prompt));
		if (!string.IsNullOrEmpty(prompt)) promptText.text = prompt;
	}
}
