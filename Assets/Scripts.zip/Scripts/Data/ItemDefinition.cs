using UnityEngine;

[CreateAssetMenu(menuName = "Game Objects/Item Definition")]
public class ItemDefinition : ScriptableObject
{
	public string itemId;
	public string displayName;
	[TextArea] public string description;
	public Sprite icon;

	public bool isKeyItem;				// true=������(����), false=�Ҹ�ǰ(����)
}