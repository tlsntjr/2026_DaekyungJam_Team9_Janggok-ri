using UnityEngine;

[CreateAssetMenu(menuName = "Project Objects/Haunt Definition")]
public class HauntDefinition : ScriptableObject
{
	public string huntId;			// "mudflat", "lighthouse", "fishfarm"
	public string regionLabel;	// FMOD "Region" �Ķ���ͷ� �ѱ� ��
}